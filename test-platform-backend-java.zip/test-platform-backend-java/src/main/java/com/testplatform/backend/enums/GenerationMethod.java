package com.testplatform.backend.enums;

public enum GenerationMethod {
    RULE_BASED,
    AI_GENERATED,
    MANUAL
}
