package com.testplatform.backend.enums;

public enum UserRole {
    ADMIN,
    DEVELOPER,
    TESTER
}
