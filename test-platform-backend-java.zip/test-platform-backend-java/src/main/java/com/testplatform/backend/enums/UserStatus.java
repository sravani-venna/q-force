package com.testplatform.backend.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
