package com.testplatform.backend.enums;

public enum TriggerType {
    MANUAL,
    PR_CREATED,
    PR_UPDATED,
    SCHEDULED,
    API
}
