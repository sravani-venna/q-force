package com.testplatform.backend.enums;

public enum TestType {
    UNIT,
    INTEGRATION,
    E2E,
    PERFORMANCE,
    SECURITY
}
