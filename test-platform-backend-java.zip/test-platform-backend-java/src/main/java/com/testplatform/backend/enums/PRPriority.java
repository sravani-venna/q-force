package com.testplatform.backend.enums;

public enum PRPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
