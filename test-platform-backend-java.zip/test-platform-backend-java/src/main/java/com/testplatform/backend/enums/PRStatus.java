package com.testplatform.backend.enums;

public enum PRStatus {
    OPEN,
    MERGED,
    CLOSED,
    DRAFT
}
