package com.testplatform.backend.enums;

public enum ExecutionType {
    SUITE,
    SINGLE_TEST,
    REGRESSION,
    SMOKE
}
