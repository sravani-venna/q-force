package com.testplatform.backend.enums;

public enum TestPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
